create definer = root@localhost view friends_view as
select `alphaguard_alpha`.`users`.`id`                AS `id`,
       `alphaguard_alpha`.`users`.`name`              AS `name`,
       `alphaguard_alpha`.`users`.`slug`              AS `slug`,
       `alphaguard_alpha`.`users`.`avatar`            AS `avatar`,
       `alphaguard_alpha`.`users`.`nickname`          AS `nickname`,
       `alphaguard_alpha`.`users`.`email`             AS `email`,
       `alphaguard_alpha`.`users`.`bio`               AS `bio`,
       `alphaguard_alpha`.`users`.`permissions_level` AS `permissions_level`,
       `alphaguard_alpha`.`users`.`is_sys_admin`      AS `is_sys_admin`,
       `alphaguard_alpha`.`users`.`is_blocked`        AS `is_blocked`,
       `alphaguard_alpha`.`users`.`blocked_reason`    AS `blocked_reason`,
       `alphaguard_alpha`.`users`.`password`          AS `password`,
       `alphaguard_alpha`.`users`.`remember_token`    AS `remember_token`,
       `alphaguard_alpha`.`users`.`created_at`        AS `created_at`,
       `alphaguard_alpha`.`users`.`updated_at`        AS `updated_at`,
       `alphaguard_alpha`.`friends`.`accepted`        AS `__friends__pivot__accepted`,
       `alphaguard_alpha`.`friends`.`created_at`      AS `__friends__pivot__created_at`,
       `alphaguard_alpha`.`friends`.`updated_at`      AS `__friends__pivot__updated_at`,
       `alphaguard_alpha`.`friends`.`user_id`         AS `laravel_foreign_key`,
       'App\\Models\\User'                            AS `laravel_model`,
       ''                                             AS `laravel_placeholders`,
       ''                                             AS `laravel_with`
from (`alphaguard_alpha`.`users` join `alphaguard_alpha`.`friends`
      on ((`alphaguard_alpha`.`users`.`id` = `alphaguard_alpha`.`friends`.`friend_id`)))
where (`alphaguard_alpha`.`friends`.`accepted` = 1)
union all
select `alphaguard_alpha`.`users`.`id`                AS `id`,
       `alphaguard_alpha`.`users`.`name`              AS `name`,
       `alphaguard_alpha`.`users`.`slug`              AS `slug`,
       `alphaguard_alpha`.`users`.`avatar`            AS `avatar`,
       `alphaguard_alpha`.`users`.`nickname`          AS `nickname`,
       `alphaguard_alpha`.`users`.`email`             AS `email`,
       `alphaguard_alpha`.`users`.`bio`               AS `bio`,
       `alphaguard_alpha`.`users`.`permissions_level` AS `permissions_level`,
       `alphaguard_alpha`.`users`.`is_sys_admin`      AS `is_sys_admin`,
       `alphaguard_alpha`.`users`.`is_blocked`        AS `is_blocked`,
       `alphaguard_alpha`.`users`.`blocked_reason`    AS `blocked_reason`,
       `alphaguard_alpha`.`users`.`password`          AS `password`,
       `alphaguard_alpha`.`users`.`remember_token`    AS `remember_token`,
       `alphaguard_alpha`.`users`.`created_at`        AS `created_at`,
       `alphaguard_alpha`.`users`.`updated_at`        AS `updated_at`,
       `alphaguard_alpha`.`friends`.`accepted`        AS `__friends__pivot__accepted`,
       `alphaguard_alpha`.`friends`.`created_at`      AS `__friends__pivot__created_at`,
       `alphaguard_alpha`.`friends`.`updated_at`      AS `__friends__pivot__updated_at`,
       `alphaguard_alpha`.`friends`.`friend_id`       AS `laravel_foreign_key`,
       'App\\Models\\User'                            AS `laravel_model`,
       ''                                             AS `laravel_placeholders`,
       ''                                             AS `laravel_with`
from (`alphaguard_alpha`.`users` join `alphaguard_alpha`.`friends`
      on ((`alphaguard_alpha`.`users`.`id` = `alphaguard_alpha`.`friends`.`user_id`)))
where (`alphaguard_alpha`.`friends`.`accepted` = 1);

